/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.salesreport;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class SalesReport {

    public static void main(String[] args) {
        System.out.println("Hello World!");

        Scanner input = new Scanner(System.in);

        // Single-dimensional array for the 3 mattress products
        String[] products = {
            "Cozy Nights Monarch mattress",
            "Restonic Barbados mattress",
            "Sealy Phuket mattress"
        };

        // Two-dimensional array: 3 products (rows) x 3 months (columns)
        int[][] sales = new int[3][3];

        // Collect user input
        for (int row = 0; row < products.length; row++) {
            for (int col = 0; col < sales[row].length; col++) {
                System.out.print("Enter number of sales for month " + (col + 1) + " for " + products[row] + ": ");
                sales[row][col] = input.nextInt();
            }
            System.out.println(); // Blank line between products
        }

        // Instantiate Product and PrintProduct classes
        Product productReport = new Product(products, sales);
        PrintProduct printer = new PrintProduct(productReport);

        // Display final report
        printer.printReport();
        
        input.close();
    }
}

