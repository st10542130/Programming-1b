/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salesreport;

/**
 *
 * @author Student
 */
class Product {

    private final String[] products;
    private final int[][] sales;

    // Constructor accepting single and two-dimensional arrays
    public Product(String[] products, int[][] sales) {
        this.products = products;
        this.sales = sales;
    }

    public int GetTotalProductsSold() {
        int total = 0;
        for (int[] sale : sales) {
            for (int col = 0; col < sale.length; col++) {
                total += sale[col];
            }
        }
        return total;
    }

    public double GetAverageProductSold() {
        int total = GetTotalProductsSold();
        int count = 0;
        for (int[] sale : sales) {
            count += sale.length;
        }
        // Returns 17.0 for the sample data (153 / 9)
        return (double) total / count;
    }

    public String GetMostPopularProduct() {
        int highestTotal = -1;
        int bestProductIndex = 0;
        int highestSingleMonth = -1;

        for (int row = 0; row < sales.length; row++) {
            int productTotal = 0;
            for (int col = 0; col < sales[row].length; col++) {
                productTotal += sales[row][col];
                if (sales[row][col] > highestSingleMonth) {
                    highestSingleMonth = sales[row][col];
                }
            }
            if (productTotal > highestTotal) {
                highestTotal = productTotal;
                bestProductIndex = row;
            }
        }
        // Returns the product name with its highest total (or swap highestTotal with highestSingleMonth to match screenshot literally)
        return products[bestProductIndex] + "(" + highestTotal + ")";
    }
}

    
