/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaguiapp;


import javax.swing.JFrame;

/**
 *
 * @author Student
 */
public class JavaGUIapp {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
 // Window configuration 
setTitle("Product App");
setSize(420, 270);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setLocationRelativeTo(null);

// Calculation logic 
final double VAT_RATE = 0.15;
final double COMMISSION_RATE = 0.05;
        double price = 0;

double vat = price * VAT_RATE;
double commission = price * COMMISSION_RATE;
double totalSale = price + vat + commission;
        String customerName = null;
        String productName = null;

// Display summary dialog 
String message = "Customer Name: " + customerName + "\n"
               + "Product: " + productName + "\n"
               + "VAT: R " + vat + "\n"
               + "COMMISSION: R " + commission + "\n"
               + "TOTAL: R " + totalSale;

    }

    private static void setTitle(String product_App) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static void setSize(int i, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static void setDefaultCloseOperation(int EXIT_ON_CLOSE) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static void setLocationRelativeTo(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
